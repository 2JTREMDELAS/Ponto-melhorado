# Bate Ponto do Xandin — versão 1.1

Projeto Android Studio em Kotlin com interface WebView, em português, com identidade visual industrial escura e detalhes em laranja.

## Funcionalidades
- Registro manual e rápido de entrada/saída, intervalo variável, observações, histórico, edição e exclusão.
- Ponto em aberto não contabiliza horas até que exista uma saída; a marcação rápida de saída não inventa entrada.
- Cálculo de horas registradas e estimativa de horas extras configurável.
- Diárias por empresa, função, data, quantidade, valor individual, recebido e saldo.
- Histórico separado de pagamentos, com data, valor, observação e recálculo de saldo.
- Relatórios mensais e resumos por empresa.
- Calendário mensal com indicação de pontos completos e em aberto; toque no dia para lançar ponto.
- Exportação de relatórios por meio da impressão do Android: escolha “Salvar como PDF” na tela de impressão.
- Exportação de diárias em CSV.
- Backup JSON e restauração com validação do arquivo; os backups antigos continuam compatíveis e pagamentos anteriores são importados para o histórico.
- PIN de 4 a 8 dígitos. No Android, o PIN é guardado em preferências privadas como hash derivado com salt aleatório; não é salvo em texto puro.
- Configurações de salário, divisor, jornada, horários, adicional e funções sugeridas.

## Dados e privacidade
- Pontos, diárias e pagamentos ficam no armazenamento local do WebView deste aparelho. Não há sincronização em nuvem.
- Faça backup JSON regularmente e guarde uma cópia fora do celular. Desinstalar ou limpar os dados do app pode apagar os registros.
- O PIN protege a abertura da interface, mas não substitui backup e não cifra o banco de dados local.
- A estimativa de horas extras é simplificada e não substitui a conferência de regras trabalhistas, acordos ou folha de pagamento.

## Como compilar
1. Abra a pasta `BatePontoDoXandin` no Android Studio.
2. Aguarde a sincronização do Gradle e instale o Android SDK 35 se solicitado.
3. Use **Build > Build APK(s)**.
4. O APK de depuração costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.

Este ZIP contém o código-fonte. O APK precisa ser compilado no Android Studio para gerar um instalador atualizado.
