package br.com.xandin.bateponto

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val pinPrefs by lazy { getSharedPreferences("xandin_security", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface
        fun saveFile(name: String, content: String, mime: String) {
            runOnUiThread {
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BatePontoDoXandin")
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                        Toast.makeText(this@MainActivity, "Arquivo salvo em Downloads/BatePontoDoXandin", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this@MainActivity, "Não foi possível criar o arquivo", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Não foi possível salvar o arquivo", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun hasPin(): Boolean = pinPrefs.contains("pin_salt") && pinPrefs.contains("pin_hash")

        @JavascriptInterface
        fun setPin(pin: String): Boolean {
            if (!pin.matches(Regex("\\d{4,8}"))) return false
            return try {
                val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                val hash = derivePin(pin, salt)
                pinPrefs.edit().putString("pin_salt", salt.toHex()).putString("pin_hash", hash.toHex()).commit()
            } catch (e: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun verifyPin(pin: String): Boolean {
            if (!hasPin() || !pin.matches(Regex("\\d{4,8}"))) return false
            return try {
                val salt = pinPrefs.getString("pin_salt", "")!!.hexToBytes()
                val expected = pinPrefs.getString("pin_hash", "")!!.hexToBytes()
                MessageDigest.isEqual(expected, derivePin(pin, salt))
            } catch (e: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun clearPin(): Boolean = pinPrefs.edit().remove("pin_salt").remove("pin_hash").commit()

        @JavascriptInterface
        fun printPdf(title: String) {
            runOnUiThread {
                try {
                    val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val safeTitle = title.replace(Regex("[^A-Za-z0-9._-]"), "-").take(80).ifBlank { "Relatorio-Bate-Ponto" }
                    manager.print(safeTitle, web.createPrintDocumentAdapter(safeTitle), PrintAttributes.Builder().build())
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Não foi possível abrir a impressão PDF", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun derivePin(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 150_000, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

    private fun String.hexToBytes(): ByteArray {
        require(length % 2 == 0)
        return chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
